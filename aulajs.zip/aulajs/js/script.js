//===============
// SHOWROOM JS
// Este arquiivo serve como laboratorio
// Selecao - eventos - manipulacao de textos
//settimeout e setintervout
//
//============-==
//1) SELECAO DE ELEMENTOS DO HTML (DOM)
//===============
//document -> representa toda a pagina HTML
//getElementById -> busca op elemento pelo atributo id
//
//
//Guardamos cada elemento em uma constante para reutilizar
//sem precisar buscar no html toda hora (boa pratica)

const saida = document.getElementById('saida');
const contadorSpan = document.getElementById('contador');
const relogioSpan = document.getElementById('relogio');
const toast = document.getElementById("toast")
const caixa = document.getElementById("caixa")
const inputNome = document.getElementById("nome")

//==================================
//2) ESTADO SIMPLES (VARIAVEL)
//==================================
//Variavel que guarda o estado da aplicação
//Aqui controlamos quantas vezes o usuario clicou em botões
let cliques = 0;
//Começa por zero porque ninguém clicou ainda

//=================================
//3) FUNÇÃO UTILITÁRIA: ESCREVER NO STATUS
//FUNÇÃO - é um bloco de codigo reutilizável

function escreverStatus (mensagem){
    saida.innerText = mensagem;
}

//===================
//TOAST (NOTIFICAÇÃO)
//===================

let toastTimer = null

function mostrarToast(msg, tipo ="info", tempoMS = 3000){
    toast.style.display = "block";
    toast.innerText = msg;

    //Ajustar a cor da borda conforme o tipo de mensagem]
    if(tipo === "sucesso"){
        toast.style.borderColor = "rgba(34,197,94,0.6)"; //Verde
        } else if (tipo === erro){
            toast.style.borderColor = "rgb(239,68,68)"; //vermelho
        }else{
            toast.style.borderColor = "rgba(255,255, 255,0.12)";
        }
    //Se ja existir um timer rodando, cancelamos
        if(toastTimer){
            clearTimeout(toastTimer);
        }  
    //Define um novo timer para esconder o Toast
    toastTimer = setTimeout(()=>{
        toast.style.display = "none";
    }, tempoMS);
}

//===============================
//Atualizar contador de Cliques
//===============================
function AtualizarContador() {
    contadorSpam.innerText = "Cliques" + cliques;
}

//========
//Relogio
//========
function AtualizarRelogio(){
    const agora = new Date(); //data e hora
    const h = String(agora.getHours()).padStart(2, "0")
    const m = String(agora.getMinutes()).padStart(2, "0")
    const s = String(agora.getSeconds()).padStart(2, "0")
    relogioSpan.innerText = `Hora: ${h}:${m}:${s}`;
}
setInterval(AtualizarRelogio, 1000);
AtualizarRelogio();